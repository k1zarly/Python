import math

z = int(input())
if z < 1:
    x = math.pow(z,3)
else:
    x = z + math.log10(z)
y = math.pow(math.cos(math.pow(x,2)),2) + math.pow(math.sin(math.pow(x,3)),2)
print(y)





